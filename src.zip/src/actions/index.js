export const getNews = () => ({
    type: 'GET_NEWS',
});